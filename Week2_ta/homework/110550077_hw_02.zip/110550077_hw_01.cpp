#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
int main() {
	printf("    *   *****   *****   *****\n");
	printf("    *       *   *   *       *\n");
	printf("    *   *****   *   *   *****\n");
	printf("    *   *       *   *   *    \n");
	printf("    *   *****   ****    *****\n");
	system("pause");
	return 0;
}