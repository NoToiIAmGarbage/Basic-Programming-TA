#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
int main() {
	int age = 18; char gender = 'M';
	printf("Age:%d\n", age);
	printf("Gender:%c\n", gender);
	system("pause");
	return 0;
}