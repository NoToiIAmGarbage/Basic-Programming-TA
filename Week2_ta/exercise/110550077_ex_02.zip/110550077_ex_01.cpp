#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
int main() {
	printf("Name:吳庭安\n");
	printf("Department:資工一\n");
	system("pause");
	return 0;
}